#pragma once
#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include "Node.h"
#include "Group.h"
#include "Element.h"
#include "Material.h"
#include "Prescribe.h"
#include "Load.h"
#include "mkl.h"

using namespace std;
class FEMOOP
{
	ofstream chk, res;
	time_t  tNow;
	struct tm   tmLocal;
	string probn, text;
	int  nnode, ndim, nelem, ngroup, nmat, nstep;
	int *ipiv;
	double *A, Error;

	int TotalDegreeOfFreedom, *DegreeOfFreedom;
	double ** GlobalStiffMatrix, *LoadMatrix, *RightHand, *InitialForce;
public:
	int InputFile();
	int OpenCheckFile();
	int ShowPassTime();
	int ReadControl();
	int ReadAllFile();	
	int TotalDOF();
	int GlobalStiff();
	int Load();
	int Solve();
	int StrainForce();
	int StepCycle();
	//

	//! PostProcess().
	/*!
	
	*/
	int PostProcess();
};
extern Node Nodes;
extern Element Elems;
extern Group Groups;
extern Load Loads;
extern Material Mats;
extern Prescribe Pres;

