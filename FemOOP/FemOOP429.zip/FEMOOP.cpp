#include "FEMOOP.h"

int FEMOOP::InputFile()
{
	ifstream inp("1.inp");
	if (inp.fail())
	{
		cout << "The input file does not exist" << endl;
		cout << "Exit program" << endl; 
		return -1;
	}
	getline(inp, text);
	getline(inp, probn);
	inp.close();
	return 0;
}
int FEMOOP::ReadControl()
{
	ifstream glb(probn + ".glb");
	if (glb.fail())
	{
		cout << "The input file does not exist" << endl;
		cout << "Exit program" << endl;
		return -1;
	}
	
	stringstream stream;
	getline(glb, text);
	getline(glb, text);
	stream << text;
	stream >> ndim >> nnode >> ngroup >>  nelem >> nmat>>nstep;
	stream.clear();
	glb.close();
	return 0;
}
int FEMOOP::ReadAllFile()
{
	Nodes.ReadFile(probn,ndim,nnode);
	Groups.ReadFile(probn, ngroup);
	Elems.ReadFile(probn, Groups,ngroup); 
	Mats.ReadFile(probn,nmat);
	Loads.ReadFile(probn);
	Pres.ReadFile(probn);
	return 0;
}
int FEMOOP::OpenCheckFile()
{
	chk.open(probn + ".chk");
	cout << "Project file located at " << probn << endl;
	chk << "Project file located at " << probn << endl;
	return 0;
}
int FEMOOP::ShowPassTime()
{
	time(&tNow);
	localtime_s(&tmLocal, &tNow);
	cout << "Current Time " << tmLocal.tm_year + 1900 << "-" << tmLocal.tm_mon + 1 << "-" <<
		tmLocal.tm_mday << setw(4) << tmLocal.tm_hour << ":" << setfill('0') << setw(2) << tmLocal.tm_min << ":"
		<< setfill('0') << setw(2) << tmLocal.tm_sec << setfill(' ') << endl;
	chk << "Current Time " << tmLocal.tm_year + 1900 << "-" << tmLocal.tm_mon << "-" <<
		tmLocal.tm_mday << setw(4) << tmLocal.tm_hour << ":" << setfill('0')  << setw(2) << tmLocal.tm_min << ":"
		<< setfill('0') << setw(2) << tmLocal.tm_sec << setfill(' ') << endl;
	return 0;
}
int FEMOOP::TotalDOF()
{
	DegreeOfFreedom = new int[nnode*ndim]();
	for (int idof = 0; idof < nnode*ndim; idof++)
	{
		DegreeOfFreedom[idof] = 1;
	}
	TotalDegreeOfFreedom=Pres.FixDof(DegreeOfFreedom, nnode*ndim);
	Elems.FillDof(DegreeOfFreedom);
	return 0;
}
int FEMOOP::GlobalStiff()
{
	GlobalStiffMatrix = new double*[TotalDegreeOfFreedom];
	for (int iFreedom = 0; iFreedom < TotalDegreeOfFreedom; iFreedom++)
	{
		GlobalStiffMatrix[iFreedom] = new double[TotalDegreeOfFreedom]();
	}
	int iedof,jedof,*Dof;
	double **Stiff;
	for (int ielem = 0; ielem < nelem; ielem++)
	{
		Stiff = Elems.GetStiff(ielem);
		Dof = Elems.GetDof(ielem);
		for (int idof = 0; idof < Elems.Ndof(ielem); idof++)
		{
			iedof = Dof[idof];
			for (int jdof = 0; jdof < Elems.Ndof(ielem); jdof++)
			{
				jedof = Dof[jdof];
				if (iedof != 0 && jedof != 0)
				{
					GlobalStiffMatrix[iedof - 1][jedof - 1] += Stiff[idof][jdof];
				}
			}
		}
	}
	return 0;
}
int FEMOOP::Load()
{
	//waiting to fill
	LoadMatrix = new double[TotalDegreeOfFreedom]();
	Loads.ApplyLoad(LoadMatrix,DegreeOfFreedom);
	return 0;
}
int FEMOOP::Solve()
{
	//waiting to fill
	ipiv = new int[TotalDegreeOfFreedom];
	RightHand = new double[TotalDegreeOfFreedom];
	InitialForce = new double[TotalDegreeOfFreedom]();
	A = new double[TotalDegreeOfFreedom*TotalDegreeOfFreedom];
	for (int iFreedom = 0; iFreedom < TotalDegreeOfFreedom; iFreedom++)
	{
		for (int jFreedom = 0; jFreedom < TotalDegreeOfFreedom; jFreedom++)
		{
			A[iFreedom*TotalDegreeOfFreedom + jFreedom] = GlobalStiffMatrix[iFreedom][jFreedom];
			//chk << setw(15) << GlobalStiffMatrix[iFreedom][jFreedom];
		}
		//chk << endl;
	}
	for (int iFreedom = 0; iFreedom < TotalDegreeOfFreedom; iFreedom++)
	{
		RightHand[iFreedom] = LoadMatrix[iFreedom];
	}
	int info = LAPACKE_dgesv(LAPACK_COL_MAJOR, TotalDegreeOfFreedom, 1, A, TotalDegreeOfFreedom, ipiv, RightHand, TotalDegreeOfFreedom);
	char trana, tranb;
	int m, n, k;
	double alpha=1.0, beta=1.0;
	trana = 'N';
	tranb = 'N';
	m = TotalDegreeOfFreedom;
	n = 1;
	k = TotalDegreeOfFreedom;
	int lda, ldb, ldc;
	lda = m; ldb = TotalDegreeOfFreedom; ldc = k;
	Result = new double[TotalDegreeOfFreedom]();
	for (int iFreedom = 0; iFreedom < TotalDegreeOfFreedom; iFreedom++)
	{
		for (int jFreedom = 0; jFreedom < TotalDegreeOfFreedom; jFreedom++)
		{
			A[jFreedom*TotalDegreeOfFreedom + iFreedom] = GlobalStiffMatrix[iFreedom][jFreedom];
		}
	}
	dgemm(&trana, &tranb, &m, &n, &k, &alpha, A, &lda, RightHand, &ldb, &beta, Result, &ldc);
	Error = 0;
	for (int iFreedom = 0; iFreedom < TotalDegreeOfFreedom; iFreedom++)
	{
		Error = pow((LoadMatrix[iFreedom] - Result[iFreedom]), 2);
	}
	
	return 0;
}
int FEMOOP::PostProcess()
{
	//waiting to fill
	chk << setw(10) << "Index"
		<< setw(15) << "Dispx"
		<< setw(15) << "Dispy"
		<< setw(15) << "Dispz"
		<< endl; 
	double *disp;
	disp = new double[ndim];
	for (int inode = 0; inode < nnode; inode++)
	{		
		chk << setw(10) << inode;
		for (int idim = 0; idim < ndim; idim++)
		{
			if (DegreeOfFreedom[inode * 2 + idim]!=0)
			{
				disp[idim] = RightHand[DegreeOfFreedom[inode * 2 + idim] - 1];
				chk << setw(15) << RightHand[DegreeOfFreedom[inode * 2 + idim] - 1];
			}
			else
			{
				disp[idim] = 0;
				chk << setw(15) << 0;
			}
			
		}
		Nodes.PutResult(inode, disp);
		chk << endl;
	}
	chk << setw(10) << "Index"
		<< setw(15) << "Dispx"
		<< setw(15) << "Dispy"
		<< setw(15) << "Dispz"
		<< endl;
	Nodes.PrintResult(chk);
	cout << setw(10) << "Index"
		<< setw(15) << "StressXX"
		<< setw(15) << "StressYY"
		<< setw(15) << "StressXY" << endl;
	chk << setw(10) << "Index"
		<< setw(15) << "StressXX"
		<< setw(15) << "StressYY"
		<< setw(15) << "StressXY" << endl;
	
	for (int ielem = 0; ielem < nelem; ielem++)
	{
		Elems.PrintStress(ielem, chk);
		Elems.PrintStress(ielem, cout);
	}
	return 0;
}
int FEMOOP::StrainForce()
{
	return 0;
}
int FEMOOP::GIDOutMesh()
{
	string GidMeshFile;
	GidMeshFile = probn + ".msh";
	GiD_OpenPostMeshFile(GidMeshFile.c_str(), GiD_PostAscii);
	GiD_BeginMesh("Static", GiD_2D, GiD_Quadrilateral, 4);
	GiD_BeginCoordinates();
	for (int inode = 0; inode < nnode; inode++)
	{
		Nodes.
	}

	return 0;
}
int FEMOOP::GIDOutResult()
{
	return 0;
}
int FEMOOP::StepCycle()
{
	InputFile();
	OpenCheckFile();
	ShowPassTime();
	ReadControl();
	ReadAllFile();
	ShowPassTime();

	TotalDOF();

	Elems.ElementStiff();

	GlobalStiff();
	ShowPassTime();
	Load();
	ShowPassTime();

	Solve();
	ShowPassTime();

	Elems.GetResult(RightHand);
	Elems.ElementStress();

	Elems.InitialStress(InitialForce);

	PostProcess();
	ShowPassTime();
	return 0;
}