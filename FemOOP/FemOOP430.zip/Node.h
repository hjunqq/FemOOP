#ifndef NODE_H
#define NODE_H
#pragma once
#include <string>

using namespace std;
class Node
{
	int nnode;
	double **val;
	double **Disp, **Strain, **Stress;
public:
	friend class Element;
	int ReadFile(ifstream &cor,int ndim,int nnode);
	double *GetCoor(int inode);
	double *GetStrain(int inode);
	double *GetDisp(int inode);
	double *GetStress(int inode);
	int PutResult(int inode, double *Disp);
	int PutResult(int inode, double *Strain,double *Stress);
	int PrintResult(ofstream &chk);
};
#endif