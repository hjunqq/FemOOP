#include "Prescribe.h"
Prescribe *Pres;
Prescribe::Prescribe()
{
}
FixBoundary::FixBoundary(string text)
{
	stringstream stream;
	stream << text;
	stream >> Dir >> Nnode;
	Dir--;
	stream.clear();
	Node = new int[Nnode];
}
int FixBoundary::AddVal(string text)
{
	stringstream stream;
	stream << text;
	for (int inode = 0; inode < Nnode; inode++)
	{
		stream >> Node[inode];
		Node[inode]--;
	}
	return 0;
}
int Prescribe::ReadFile(ifstream &pre)
{
	
	string text;
	stringstream stream;
	getline(pre, text);
	getline(pre, text);
	stream << text;
	stream >> npre;
	stream.clear();
	for (int ipre = 0; ipre < npre; ipre++)
	{
		getline(pre, text);
		type.push_back(text);
		if (text == "FixBoundary")
		{
			getline(pre, text);
			stream << text;
			stream >> ndim;
			stream.clear();
			for (int idim = 0; idim < ndim; idim++)
			{
				getline(pre, text);
				getline(pre, text);
				stream << text;
				Fix.push_back(text);
				getline(pre, text);
				Fix[idim].AddVal(text);
			}
		}
	}
	return 0;
}
int FixBoundary::Get(string text)
{
	if (text == "Dir")
	{
		return Dir;
	}
	else if (text == "Nnode")
	{
		return Nnode;
	}
	return -1;
}
int FixBoundary::Get(int index)
{
	return Node[index];
}
int Prescribe::FixDof(int *DegreeOfFreedom, int n)
{
	for (int ipre = 0; ipre < npre; ipre++)
	{
		if (type.at(ipre) == "FixBoundary")
		{
			for (int idim = 0; idim < ndim; idim++)
			{
				if (idim == Fix[idim].Get("Dir") )
				{
					for (int inode = 0; inode < Fix[idim].Get("Nnode"); inode++)
					{
						DegreeOfFreedom[(Fix[idim].Get(inode)) * 2 + idim] = 0;
					}
				}
			}
		}

	}
	int TotalDegreeOfFreedom = 0;
	for (int idof = 0; idof < n; idof++)
	{
		if (DegreeOfFreedom[idof] != 0)
		{
			TotalDegreeOfFreedom++;
			DegreeOfFreedom[idof] = TotalDegreeOfFreedom;
		}
	}

	return TotalDegreeOfFreedom;
}
Prescribe::~Prescribe()
{
}
