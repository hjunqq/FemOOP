#include "Node.h"
#include "FEMOOP.h"
Node Nodes;


int Node::ReadFile(ifstream &cor,int ndim,int nnode)
{
	this->nnode = nnode;
	val = new double*[nnode];
	Disp = new double*[nnode];
	Strain = new double *[nnode];
	Stress = new double *[nnode];
	for (int inode = 0; inode < nnode; inode++)
	{
		val[inode] = new double[ndim];
		Disp[inode] = new double[ndim]();
		Strain[inode] = new double[3]();
		Stress[inode] = new double[3]();
	}
	
	stringstream stream;
	string text;
	
	int idx;
	if (ndim == 2)
	{
		for (int inode = 0; inode < nnode; inode++)
		{
			getline(cor, text);
			stream << text << endl;
			stream >> idx >> val[inode][0] >> val[inode][1];
			idx--;
			stream.clear();
		}
	}
	else if (ndim == 3)
	{
		for (int inode = 0; inode < nnode; inode++)
		{
			getline(cor, text);
			stream << text << endl;
			stream >> idx >> val[inode][0] >> val[inode][1] >> val[inode][2];
			idx--;
			stream.clear();
		}
	}
	return 0;
}
double *Node::GetCoor(int inode)
{
	return val[inode]; 
}
double *Node::GetDisp(int inode)
{
	return Disp[inode];
}
double *Node::GetStrain(int inode)
{
	return Strain[inode];
}
double *Node::GetStress(int inode)
{
	return Stress[inode];
}
int Node::PutResult(int inode, double *Disp)
{
	for (int i = 0; i < 2; i++)
	{
		this->Disp[inode][i] = Disp[i];
	}
	return 0;
}
int Node::PutResult(int inode, double *Strain,double *Stress)
{
	for (int i = 0; i < 3; i++)
	{
		this->Strain[inode][i] = Strain[i];
		this->Stress[inode][i] = Stress[i];
	}
	return 0;
}
int Node::PrintResult(ofstream &chk)
{
	for (int inode = 0; inode < nnode; inode++)
	{
		chk << setw(10) << inode
			<< setw(15) << Disp[inode][0]
			<< setw(15) << Disp[inode][1]<<endl;
	}
	return 0;
}