#ifndef PRE_H
#define PRE_H
#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
using namespace std;
class FixBoundary
{
	int Dir, Nnode;
	int *Node;
public:
	FixBoundary(string text);
	int AddVal(string text);
	int Get(string text);
	int Get(int index);
};
class Prescribe
{
	int npre,ndim;
	vector<FixBoundary> Fix;
	vector<string> type;
public:
	Prescribe();
	int ReadFile(ifstream &pre);
	int FixDof(int *DegreeOfFreedom, int n);
	~Prescribe();
};

#endif