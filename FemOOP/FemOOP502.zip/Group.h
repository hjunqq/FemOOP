#ifndef GROUP_H
#define GROUP_H
#pragma once
#include <string>
#include <vector>
#include <sstream>
using namespace std;
class Info
{
	int Index,Type, Nelem, Material;
	int *Elem;
public:
	Info(string text);
	int Get(string VarName);
};
class Group
{
	vector<Info> GList;
public:
	int ReadFile(ifstream &grp,int ngroup);
	int Get(int igroup,string VarName);
};


#endif