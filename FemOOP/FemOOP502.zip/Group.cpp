#include "Group.h"
#include "FEMOOP.h"
Group Groups;
Info::Info(string text)
{
	stringstream stream;
	stream<< text;
	stream >> Index >> Type >> Nelem >> Material;
	Index--;
	Material--;
	Elem = new int[Nelem];
}
int Info::Get(string VarName)
{
	if (VarName == "Type")
	{
		return Type;
	}
	else if (VarName == "Nelem")
	{
		return Nelem;
	}
	else if (VarName == "Material")
	{
		return Material;
	}
	return -1;
}

int Group::Get(int igroup,string VarName)
{
	return GList[igroup].Get(VarName);
}
int Group::ReadFile(ifstream &grp,int ngroup)
{
	string text;
	stringstream stream;
	
	for (int igroup = 0; igroup < ngroup; igroup++)
	{
		getline(grp, text);
		getline(grp, text);
		GList.push_back(text);
	}
	return 0;
}
