#ifndef PRE_H
#define PRE_H
#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "Element.h"
using namespace std;
class FixBoundary
{
	int Dir, Nnode;
	int *Node;
public:
	FixBoundary(string text);
	int AddVal(string text);
	int Get(string text);
	int Get(int index);
};
class Displacement
{
	int Dir, Nnode;
	double Value;
	int *Node;
public:
	Displacement(string text);
	int AddNode(string text);
	int ApplyDisp(double *LoadMatrix, int *DegreeOfFreedom, int TotalDegreeOfFreedom, int TotalNode, int NodeDof,int nelem);
	int GetNnode();
	int GetDir();
	int GetNode(int inode);
};
class Prescribe
{
	int npre,ndim,nDisp;
	vector<FixBoundary> Fix;
	vector<Displacement>Disp;
	vector<int>Index;
	vector<string> type;
public:
	Prescribe();
	int ReadFile(ifstream &pre);
	int FixDof(int *DegreeOfFreedom, int n);
	int ApplyDisp(double *LoadMatrix, int *DegreeOfFreedom, int TotalDegreeOfFreedom, int TotalNode, int NodeDof,int nelem);
	~Prescribe();
};

#endif